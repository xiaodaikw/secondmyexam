package FinallyTest;

public class StudentDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student zhang=new Student();
		Student wang=new Student();
		Student jiang=new Student();
		System.out.println("zhang.num="+zhang.add1());
		System.out.println("zhang.num="+zhang.add2());
		System.out.println("wang.num="+wang.add1());
		System.out.println("wang.num="+wang.add2());
		System.out.println("jiang.num="+jiang.add1());
		System.out.println("jiang.num="+jiang.add2());
		

	}

}
