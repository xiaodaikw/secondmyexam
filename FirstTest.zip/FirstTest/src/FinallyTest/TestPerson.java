package FinallyTest;

public class TestPerson {
	public static void main(String[] args){
		Person p1=new Person("����","��",20);
		System.out.println("count="+p1.getCount()+"\t");
		Person p2=new Person("Tom","M",23);
		System.out.println("count="+p2.getCount()+"\t");
		Person p3=new Person("Mary","F",20);
		System.out.println("count="+p3.getCount()+"\t");
		
		System.out.println("ͨ�������Ͳ�ͬ���������ʾ�̬����count");
		System.out.println("count="+Person.getCount()+"\n");
		System.out.println("count="+p1.getCount()+"\t");
		System.out.println("count="+p2.getCount()+"\t");
		System.out.println("count="+p3.getCount()+"\n");
	}

}
