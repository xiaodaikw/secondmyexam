package FinallyTest;

public class Person {
	String name;
	String sex;
	int age;
	private static int count;
	public  static int getCount(){
		return count;
	}
	public Person(String n,String s,int a){
		name=n;
		sex=s;
		age=a;
		count++;
	}
	public String toString(){
		String s="����"+name+"�Ա�"+sex+"����"+age;
		return s;
	}
}
