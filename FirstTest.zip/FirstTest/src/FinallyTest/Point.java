package FinallyTest;

public class Point {
	final static Point origin=new Point(0,0);
	int x,y;
	Point(int x,int y){
		this.x=x;
		this.y=y;
	}
	
	
	

}
